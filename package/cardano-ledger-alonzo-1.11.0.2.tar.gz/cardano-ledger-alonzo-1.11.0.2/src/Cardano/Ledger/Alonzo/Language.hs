module Cardano.Ledger.Alonzo.Language
  {-# DEPRECATED "Use \"Cardano.Ledger.Plutus.Language\" instead" #-}
  (module Cardano.Ledger.Plutus.Language) where

import Cardano.Ledger.Plutus.Language
