module Cardano.Ledger.Shelley.EpochBoundary
  {-# DEPRECATED "Use 'import Cardano.Ledger.EpochBoundary' instead" #-} (
  module X,
)
where

import Cardano.Ledger.EpochBoundary as X
