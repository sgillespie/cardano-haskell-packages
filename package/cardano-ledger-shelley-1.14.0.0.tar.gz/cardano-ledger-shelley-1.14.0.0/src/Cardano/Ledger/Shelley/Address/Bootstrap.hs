module Cardano.Ledger.Shelley.Address.Bootstrap
  {-# DEPRECATED "Use 'import Cardano.Ledger.Keys.Bootstrap' instead" #-} (
  module X,
)
where

import Cardano.Ledger.Keys.Bootstrap as X
