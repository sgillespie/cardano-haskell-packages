module Cardano.Ledger.Shelley.PoolParams
  {-# DEPRECATED "Use 'import Cardano.Ledger.PoolParams' instead" #-} (
  module X,
)
where

import Cardano.Ledger.PoolParams as X
