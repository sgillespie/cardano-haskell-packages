module Cardano.Ledger.Shelley.Delegation.Certificates
  {-# DEPRECATED "Use `Cardano.Ledger.Shelley.TxCert` instead" #-} (
  module Cardano.Ledger.Shelley.TxCert,
) where

import Cardano.Ledger.Shelley.TxCert
