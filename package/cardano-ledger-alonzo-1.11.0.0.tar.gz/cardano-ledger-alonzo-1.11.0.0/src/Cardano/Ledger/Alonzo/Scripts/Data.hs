module Cardano.Ledger.Alonzo.Scripts.Data
  {-# DEPRECATED "Use \"Cardano.Ledger.Plutus.Data\" instead" #-}
  (module Cardano.Ledger.Plutus.Data) where

import Cardano.Ledger.Plutus.Data
